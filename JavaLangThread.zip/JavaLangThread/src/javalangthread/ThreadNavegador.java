/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javalangthread;

import java.awt.Component;
import java.util.Locale;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

/**
 *
 * @author Carol
 */
public class ThreadNavegador implements Runnable{
    
    JLabel label;
    JFrame pista;
    String name;
    int id;
    boolean fim;
    
    
    
    //private boolean mostrouResultado;
    
    void Run(){
        
    }

    @Override
    public void run() {
        
        //Variavel para gerar nums aleatorios
        Random r = new Random();
        
        while(!fim){
            
            int n = r.nextInt(6);
            
            if(label.getX()+80 < pista.getWidth())
            {
                label.setLocation(label.getX() + n, label.getY());
                pista.repaint();
                
                try {
                    Thread.sleep(15);
                } catch (InterruptedException ex) {
                    Logger.getLogger(ThreadNavegador.class.getName()).log(Level.SEVERE, null, ex);
                }
                
            }
            
            else
            {
                fim = true;
                
            }
                
        }
        
        
        
        //JOptionPane.showMessageDialog(null, "Vencedor: "+ id);
        JOptionPane.showMessageDialog(null, "Vencedor: "+ name);
    }
}
